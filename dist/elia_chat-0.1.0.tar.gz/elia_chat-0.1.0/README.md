# Elia

A quick experiment using Textual to demonstrate how you might
build a ChatGPT client in the terminal.
